# वोटर पर्ची (Android)

ग्राम पंचायत श्री टीकमगढ़ (पं. समिति आडेल, जिला बाड़मेर), वार्ड 1–7 की निर्वाचक नामावली 2026 से बनी ऑफ़लाइन पर्ची-ऐप। 1,332 वोटर।

## Build (Android Studio)
1. Android Studio (Koala या नया, JDK 17) में यह फोल्डर खोलें, Gradle Sync होने दें।
2. Run ▶ से फोन/इमुलेटर पर चलाएँ, या Build > Build APK(s)।
(AGP 8.5.2, Gradle 8.7, compileSdk 34, minSdk 21; कोई बाहरी लाइब्रेरी नहीं, INTERNET अनुमति नहीं।)

## डेटा बदलना
- ऐप के भीतर: "डेटा / पर्ची सेटिंग" > फाइल चुनें (CSV/JSON), या सुधार हर पर्ची पर "✏️ सुधारें" से।
- प्रोजेक्ट में: `build_tools/build.py` से `app/src/main/assets/data.js` दोबारा बनता है; `voters.csv` वही डेटा है। (build.py को `[{w,s,n,t,r,h,a,g,c}]` JSON दें।)
- CSV कॉलम: ward,serial,name,relation_type,relation_name,house,age,gender,check

## प्रिंट
"Print Slip" Android का प्रिंट डायलॉग खोलता है (प्रिंटर या "Save as PDF")। सिर्फ़ वही पर्ची, A5 पर।
