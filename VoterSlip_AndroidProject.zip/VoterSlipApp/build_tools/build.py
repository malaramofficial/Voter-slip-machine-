"""out/final.json (OCR से बना अंतिम डेटा) -> app/src/main/assets/{index.html,data.js}, voter_slip.html, voters.csv"""
import json, sys, csv, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
final = json.load(open(sys.argv[1]))          # [{w,s,n,t,r,h,a,g,c}, ...]
meta = {
  "gp": "श्री टीकमगढ़", "ps": "आडेल", "zp": "बाड़मेर",
  "booths": {
    "1": "15 - राजकीय प्राथमिक विद्यालय खेराजराम पोटलियां की ढाणी दाया भाग",
    "2": "15 - राजकीय प्राथमिक विद्यालय खेराजराम पोटलियां की ढाणी दाया भाग",
    "3": "15 - राजकीय प्राथमिक विद्यालय खेराजराम पोटलियां की ढाणी दाया भाग",
    "4": "16 - राजकीय प्राथमिक विद्यालय खेराजराम पोटलियां की ढाणी बायां भाग",
    "5": "16 - राजकीय प्राथमिक विद्यालय खेराजराम पोटलियां की ढाणी बायां भाग",
    "6": "16 - राजकीय प्राथमिक विद्यालय खेराजराम पोटलियां की ढाणी बायां भाग",
    "7": "16 - राजकीय प्राथमिक विद्यालय खेराजराम पोटलियां की ढाणी बायां भाग"},
}
rows = [{"w": r["w"], "s": r["s"], "n": r["n"], "t": r["t"], "r": r["r"], "h": r["h"], "a": r["a"], "g": r["g"], "c": r["c"]} for r in final]
rows.sort(key=lambda r: (r["w"], r["s"]))
data_js = "window.VOTER_META=" + json.dumps(meta, ensure_ascii=False) + ";\nwindow.VOTER_DATA=" + json.dumps(rows, ensure_ascii=False, separators=(",", ":")) + ";\n"
tpl = open(ROOT + "/build_tools/template.html", encoding="utf-8").read()
assets = ROOT + "/app/src/main/assets"
open(assets + "/data.js", "w", encoding="utf-8").write(data_js)
open(assets + "/index.html", "w", encoding="utf-8").write(tpl.replace("<!--DATA-->", '<script src="data.js"></script>'))
open(ROOT + "/voter_slip.html", "w", encoding="utf-8").write(tpl.replace("<!--DATA-->", "<script>\n" + data_js + "</script>"))
with open(ROOT + "/voters.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f); w.writerow(["ward", "serial", "name", "relation_type", "relation_name", "house", "age", "gender", "check"])
    for r in rows: w.writerow([r["w"], r["s"], r["n"], r["t"], r["r"], r["h"], r["a"], r["g"], 1 if r["c"] else ""])
print("rows", len(rows), "flagged", sum(r["c"] for r in rows))
